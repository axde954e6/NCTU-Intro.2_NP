TCP server/client
for server
python3 server.py <host>
ex: python3 server.py 7890

for client
python3 client.py <ip> <host>
ex: python3 client.py 127.0.0.1 7890